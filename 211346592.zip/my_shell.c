#include "kernel/fcntl.h"
#include "kernel/types.h"
#include "user/user.h"
#include <stddef.h>
#define MAXARG 20

// struct to hold command
struct command
{
  int type;
};

// struct to execute command
struct executecommand
{
  int type;
  char *argv[MAXARG];
};

// struct to execute redirection
struct redirectcommand
{
  int type;
  struct command *cmd;
  char *file;
  int mode;
  int fd;
};
// struct to execute pipes
struct pipecommand
{
  int type;
  struct command *left;
  struct command *right;
};

int fork1(void);
struct command *parsecmd(char *);

// Execute cmd.  Never returns.
void runcmd(struct command *cmd)
{
  int fd_redirect;
  int p[2];
  struct executecommand *execcmd;
  struct pipecommand *pipcmd;
  struct redirectcommand *redircmd;

  if (cmd == 0)
    exit(1); // exit on error

  switch (cmd->type)
  {
  default:
    fprintf(2, "runcmd\n");
    exit(1);

  case ' ':
    // code for executing command with no symbols
    execcmd = (struct executecommand *)cmd;
    if (execcmd->argv[0] == 0)
      exit(1);
    exec(execcmd->argv[0], execcmd->argv);
    break;

  case '>':
    // code for doing outputredirection
    redircmd = (struct redirectcommand *)cmd;
    close(redircmd->fd);
    if ((fd_redirect = open(redircmd->file, redircmd->mode)) < 0)
    {

      fprintf(2, "open %s has failed\n", redircmd->file);
      exit(1);
    }
    runcmd(redircmd->cmd);
    break;
  case '<':
    // code for input redirection
    redircmd = (struct redirectcommand *)cmd;
    close(redircmd->fd);
    if ((fd_redirect = open(redircmd->file, redircmd->mode)) < 0)
    {

      fprintf(2, "open %s has failed\n", redircmd->file);
      exit(1);
    }
    runcmd(redircmd->cmd);
    break;

  case '|':
    // code for handling pipes
    pipcmd = (struct pipecommand *)cmd;
    if (pipe(p) < 0)
    {
      fprintf(2, "pipe has failed\n");
      exit(1);
    }
    if (fork1() == 0)
    {
      close(1);
      dup(p[1]);
      close(p[0]);
      close(p[1]);
      runcmd(pipcmd->left);
    }
    if (fork1() == 0)
    {
      close(0);
      dup(p[0]);
      close(p[0]);
      close(p[1]);
      runcmd(pipcmd->right);
    }
    close(p[0]);
    close(p[1]);
    wait(0);
    wait(0);
    break;
  }

  exit(0);
}

int main(int argc, char *argv[])
{

  // Declare internal variables.
  char *args[MAXARG] = {0};
  // Storage for each line of standard input.
  char buf[512], *b;
  // Point b to the first character in the line.
  b = buf;

  // Read in the pointers to the arguments passed into the
  // xargs. Do not include the first argument which is 'xargs'.
  for (int i = 1; i < argc; i++)
    args[i - 1] = argv[i];

  char **a;
  a = &args[argc - 1];
  char tempbuf[512];
  char *l;

  // Read characters from the standard input. When we find '\n' that
  // means one line has terminated
  write(2, ">>> ", 4);
  while (read(0, b, 1) > 0)
  {
    if (*b == '\n')
    {
      // Replace the end of line character by the string terminating
      // character.
      *b = '\0';
      strcpy(tempbuf, buf);
      l = tempbuf;
      int ws = 0;
      while (*l != '\0')
      {
        if (*b != ' ')
        {
          // New word has started. Save the pointer to it to args.
          if (ws)
          {
            *a = l;
            ws = 0;
          }
        }
        else
        {
          // A word in the line has ended since we met a space.
          if (!ws)
          {
            *l = '\0';
            a++;
            ws = 1;
          }
        }
        l++;
      }
      if (strcmp("cd", args[0]) == 0) // if the first word is cd change directory
      {
        chdir(args[1]);
      }
      else // if not just normally execute line
      {
        if (fork1() == 0)
        {
          runcmd(parsecmd(buf));
          exit(0);
        }
        wait(0);
      }

      // When a line has been executed, point b to the start of the
      // buf where a new line will be stored.
      b = buf;
      write(2, ">>> ", 4); // write the >>> before the line
    }
    else
      b++;
  }
  exit(0);
}
int fork1(void)
{
  int pid;
  // fork checking
  // if fork doesnt work exit
  // show error message
  pid = fork();
  if (pid == -1)
  {
    fprintf(2, "fork\n");
    exit(1);
  }
  return pid;
}

struct command *
execcmd(void)
{
  struct executecommand *cmd;
  // initialise values
  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = ' ';
  return (struct command *)cmd;
}

struct command *
redircmd(struct command *subcmd, char *file, int type)
{
  struct redirectcommand *cmd;
  // initialise values for redirect command
  // like input or output and file
  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = type;
  cmd->cmd = subcmd;
  cmd->file = file;
  cmd->mode = (type == '<') ? O_RDONLY : O_WRONLY | O_CREATE | O_TRUNC; // saying the read/write parameters that need to be set
  cmd->fd = (type == '<') ? 0 : 1;
  return (struct command *)cmd;
}

struct command *
pipecmd(struct command *left, struct command *right)
{
  struct pipecommand *cmd;
  // using information from parsing to fill the struct
  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = '|';
  cmd->left = left;
  cmd->right = right;
  return (struct command *)cmd;
}

// Parsing

char whitespace[] = " \t\r\n\v";
char symbols[] = "<|>";

// jump over white spaces at start of input
// parse the command
// return character after looking thought the input and set return as a
int gettoken(char **ps, char *es, char **q, char **eq)
{
  char *s;
  int ret;

  s = *ps;
  while (s < es && strchr(whitespace, *s))
    s++;
  if (q)
    *q = s;
  ret = *s;
  switch (*s)
  {
  case 0:
    break;
  case '|':
  case '<':
    s++;
    break;
  case '>':
    s++;
    break;
  default:
    ret = 'a';
    while (s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
      s++;
    break;
  }
  if (eq)
    *eq = s;

  while (s < es && strchr(whitespace, *s))
    s++;
  *ps = s;
  return ret;
}

int peek(char **ps, char *es, char *toks)
{
  char *s;
  s = *ps;
  while (s < es && strchr(whitespace, *s))
    s++;
  *ps = s; // jump over the white space and set the new input at pointer to where words start
  return *s && strchr(toks, *s);
}

struct command *parseline(char **, char *);
struct command *parsepipe(char **, char *);
struct command *parseexec(char **, char *);

// make a copy of the characters in the input buffer, starting from s through es.
// null-terminate the copy to make it a string.
char *mkcopy(char *s, char *es)
{
  int n = es - s;
  char *c = malloc(n + 1);
  for (int i = 0; i < n; i++)
  { // setting every value in s to c
    c[i] = s[i];
  }
  c[n] = 0; // null character to make sting
  return c;
}

struct command *
parsecmd(char *s)
{
  char *es;
  struct command *cmd;

  es = s + strlen(s);//find end of string
  cmd = parseline(&s, es);//parse the line
  peek(&s, es, ""); //check for unexpected stuff
  if (s != es)
  { // if user has entered syntax in wrong
    fprintf(2, "leftovers: %s\n", s);
    exit(1);
  }
  return cmd;
}

struct command *
parseline(char **ps, char *es)
{
  struct command *cmd; // stores parsed line
  cmd = parsepipe(ps, es); //parse command line as sequence of piped commands
  return cmd;
}

struct command *
parsepipe(char **ps, char *es)
{
  struct command *cmd;
  // used because unsure of how many pipes could be in line
  cmd = parseexec(ps, es);
  if (peek(ps, es, "|")) // looking for pipes
  {
    gettoken(ps, es, 0, 0);                // jump over spaces and parse command
    cmd = pipecmd(cmd, parsepipe(ps, es)); // redifining command
  }
  return cmd;
}

struct command *
parseredirs(struct command *cmd, char **ps, char *es)
{
  int tok;
  char *q, *eq;

  while (peek(ps, es, "<>")) // looking for redirection identifiers
  {
    tok = gettoken(ps, es, 0, 0);
    if (gettoken(ps, es, &q, &eq) != 'a') // if not found redirection file
    {
      fprintf(1, "missing file for redirection\n");
      exit(1);
    }
    switch (tok)
    { // find the type of redirection needed output or input
    case '<':
      cmd = redircmd(cmd, mkcopy(q, eq), '<');
      break;
    case '>':
      cmd = redircmd(cmd, mkcopy(q, eq), '>');
      break;
    }
  }
  return cmd;
}

// yakes string input check for <>|
struct command *
parseexec(char **ps, char *es)
{
  char *q, *eq;
  int tok, argc;
  struct executecommand *cmd;
  struct command *ret; // return value a type of command

  ret = execcmd();//create execcmd command
  cmd = (struct executecommand *)ret;

  argc = 0;
  ret = parseredirs(ret, ps, es);//check for redirection
  while (!peek(ps, es, "|"))//while no pipes
  {
    if ((tok = gettoken(ps, es, &q, &eq)) == 0)
      break;//exit if there are no more tokens
    if (tok != 'a')
    {
      fprintf(2, "syntax error\n");
      exit(1);
    }
    cmd->argv[argc] = mkcopy(q, eq);
    argc++;
    if (argc >= MAXARG) // exit if there are too many arguments
    {
      fprintf(2, "too many args\n");
      exit(1);
    }
    ret = parseredirs(ret, ps, es);//check for redirection
  }
  cmd->argv[argc] = 0;//null terminate argument list
  return ret;
}
/*

https://n132.github.io/2022/02/27/How-does-shell-work.html
https://github.com/ag6288/XV6-Shell-Implementation/blob/master/shell.c
https://github.com/mit-pdos/xv6-riscv/blob/riscv/user/sh.c#L329
https://youtu.be/ubt-UjcQUYg?si=iAgK7mHLQ9N0t

*/